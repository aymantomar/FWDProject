import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { ProdcutDto } from '../model/prodcut.model';


@Injectable({
  providedIn: 'root'
})
export class CartService {
  // productList = []
  private productsList:ProdcutDto[] = []
  private productsList$ = new BehaviorSubject<ProdcutDto[]>([]);
  count: number = 1;
  //getshoppingItem = this.shoppingCart.asObservable();

  getproductList() {
    return this.productsList$.asObservable();
  }


  constructor() {

  }

  addProductToCart(product:ProdcutDto) {
    this.productsList.push(product);
    this.productsList$.next(this.productsList)
  }

  removeProductfromCart(productId) {
    const productItem = this.productsList.findIndex(item => item.id === productId);
    this.productsList.splice(productItem, 1)
    this.productsList$.next(this.productsList)
  }

  // getProductToCart(id) {
  // this.shoppingCart.next(id)
  // }
}
