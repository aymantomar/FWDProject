import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable , BehaviorSubject } from 'rxjs';
import { ProdcutDto } from './../model/prodcut.model';



@Injectable({
  providedIn: 'root'
})
export class ProdcutService {
  // private count = new BehaviorSubject(1);
  // itemCount = this.count.asObservable();

  //prodcutList: ProdcutDto[] = [];

  constructor(private http: HttpClient) { }

 getProducts(): Observable<ProdcutDto[]> {
    return this.http.get<ProdcutDto[]>('../../assets/data.json');
 }
  // changeCount(count: number) {
  //   this.count.next(count);
  // }
}
