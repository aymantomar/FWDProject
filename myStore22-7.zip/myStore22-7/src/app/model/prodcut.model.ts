export class ProdcutDto{
    id: number;
    name: string;
    price: number;
    url: string;
    description: string;
    count?:number
}
