import { CartService } from './../../shared/cart.service';
import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ProdcutDto } from 'src/app/model/prodcut.model';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.scss']
})
export class CartComponent implements OnInit {

  fullName: string;
  userAddress: string;
  userCredit: number

  shoppingCartItem : Observable<ProdcutDto[]>;

  signUpforms: FormGroup;

  removeProductFromCart;

  constructor(private route: Router, private cartService:CartService) { }

  ngOnInit() {
    this.signUpforms = new FormGroup({
      'fullName': new FormControl(null, [Validators.required, Validators.minLength(3)]),
      'address': new FormControl(null, [Validators.required, Validators.minLength(6)]),
      'credit': new FormControl(null, [Validators.required, Validators.minLength(16)]),
    });


    // this.cartService.getshoppingItem.subscribe()




    this.shoppingCartItem = this.cartService.getproductList()

  }

  ngSubmit() {
    const firstname = this.signUpforms.get('fullName').value;
    console.log(this.signUpforms.value)
    return this.route.navigate(['/confirmation/',firstname])
  }



  removeProduct() {
    this.removeProductFromCart = this.cartService.removeProductfromCart(this.shoppingCartItem)
  }

}
