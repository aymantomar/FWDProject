import { ProdcutDto } from './../../model/prodcut.model';
import { ProdcutService } from './../../shared/prodcut.service';

import { Component, Input, OnInit } from '@angular/core';
import { Observable } from 'rxjs';


@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.scss']
})
export class ProductListComponent implements OnInit {

  prodcut: ProdcutDto[];



  constructor(private prodcutService: ProdcutService) {}

  ngOnInit() {

    this.prodcutService.getProducts().subscribe(resData => {
     for (let index = 0; index < resData.length; index++) {
       const prodcut = resData[index];
       prodcut["count"]
     }
      this.prodcut = resData
    })
  }


}
