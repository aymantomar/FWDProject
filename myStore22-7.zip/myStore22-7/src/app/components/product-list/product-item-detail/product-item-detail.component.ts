import { Component, ElementRef, Input, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute , Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { ProdcutDto } from 'src/app/model/prodcut.model';
import { ProdcutService } from 'src/app/shared/prodcut.service';
import { CartService } from './../../../shared/cart.service';


@Component({
  selector: 'app-product-item-detail',
  templateUrl: './product-item-detail.component.html',
  styleUrls: ['./product-item-detail.component.scss']
})
export class ProductItemDetailComponent implements OnInit {
  prodcut: ProdcutDto
  productName
  // @ViewChild('countItem', {static: false}) countItem: ElementRef;

  getItemValue:number
  count: number = 1;
  subscription:Subscription

  constructor(private activatedRoute : ActivatedRoute , private prodcutService :ProdcutService , private cartService:CartService  , private route:Router) { }

  addtocard() {
    alert(' - ' + this.prodcut.name + ' - ' + ' Is Added To Cart Successfully')
    // this.getItemValue = this.countItem.nativeElement.value
    console.log('Input Number' + this.getItemValue)
    this.cartService.addProductToCart(this.prodcut)
    return this.route.navigate(['/cart'])
  }
  increment() {
    this.count++;
  }
  decrement() {
    this.count--;
  }

  ngOnInit() {
    console.log("count is " + this.count);
    // use name here for SEO in url
    this.productName = this.activatedRoute.snapshot.params['name'];
    this.prodcutService.getProducts().subscribe(resData => {
      resData.forEach(item => {
        if (item.name == this.productName) {
         this.prodcut = item
        }
    });
    })
    // console.log('xxxxxxxxx' + this.subscription)
    // this.subscription = this.prodcutService.itemCount.subscribe(count =>this.count=count)
    // console.log('axxxxxxxxx' + this.subscription)
  }

  goTOProductlist() {
    return this.route.navigate(['/prodcut-list'])
  }


}
