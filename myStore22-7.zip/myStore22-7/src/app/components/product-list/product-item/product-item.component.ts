
import { Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { CartService } from './../../../shared/cart.service';
import { ProdcutDto } from './../../../model/prodcut.model';


@Component({
  selector: 'app-product-item',
  templateUrl: './product-item.component.html',
  styleUrls: ['./product-item.component.scss']
})
export class ProductItemComponent implements OnInit{

  @Input() prodcut: ProdcutDto

  constructor(private cartService: CartService) {

  }

  productId:number
  getItemValue:number
  count : number = 1;


  ngOnInit() {
  }

  addtocard() {
    alert(' - ' + this.prodcut.name + ' - ' +  ' ' +this.count + ' ' +  '-'  +' Is Added To Cart Successfully')
    this.cartService.addProductToCart(this.prodcut)
  }
  increment() {
    this.count++;
  }
  decrement() {
    this.count--;
  }

}
