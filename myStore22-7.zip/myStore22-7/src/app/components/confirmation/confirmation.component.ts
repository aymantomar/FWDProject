import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-confirmation',
  templateUrl: './confirmation.component.html',
  styleUrls: ['./confirmation.component.scss']
})
export class ConfirmationComponent implements OnInit {

  firstname:string=''

  constructor(private activatedRoute: ActivatedRoute, private route : Router) { }

  ngOnInit() {
    this.activatedRoute.params.subscribe(params => {
      this.firstname = params['firstname'];
    })
  }

  goTOProductlist() {
    return this.route.navigate(['/prodcut-list'])
  }

}
